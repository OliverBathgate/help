import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.GPFitnessFunction;
import org.jgap.gp.GPProblem;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.function.*;
import org.jgap.gp.impl.DeltaGPFitnessEvaluator;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.GPGenotype;
import org.jgap.gp.terminal.Terminal;
import org.jgap.gp.terminal.Variable;
import java.io.*;
import java.util.*;
import static java.lang.Float.parseFloat;

public class a2Part2 extends GPProblem {

  private static float x[], y[];
  public static Variable vx;
  private static final int input_size = 20;

  public a2Part2(GPConfiguration a_conf)
          throws InvalidConfigurationException {
    super(a_conf);
  }

  public static void main(String[] args) throws Exception {

    x = new float[input_size];
    y = new float[input_size];

    ArrayList<String> data = new ArrayList<>();
    try {
      BufferedReader bf = new BufferedReader(new FileReader(args[0]));
      bf.readLine();
      bf.readLine();
      String line;
      while ((line = bf.readLine()) != null) {
        data.add(line);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    for (int i = 0; i < data.size(); i++) {
      StringTokenizer st = new StringTokenizer(data.get(i));
      while (st.hasMoreTokens()) {
        x[i] = parseFloat(st.nextToken());
        y[i] = parseFloat(st.nextToken());
      }

    }
    GPConfiguration con = new GPConfiguration();
    con.setGPFitnessEvaluator(new DeltaGPFitnessEvaluator());
    try {
      con.setFitnessFunction(new a2Part2.FormulaFitnessFunction());
    } catch (InvalidConfigurationException e) {
      e.printStackTrace();
    }
    con.setMaxInitDepth(5);
    con.setPopulationSize(1000);
    con.setMaxCrossoverDepth(8);
    con.setStrictProgramCreation(true);
    con.setReproductionProb(0.2f);
    con.setCrossoverProb(0.9f);
    con.setMutationProb(35.0f);
    GPProblem problem = new a2Part2(con);
    GPGenotype gp = problem.create();
    gp.setVerboseOutput(true);
    gp.evolve(1000);
    gp.outputSolution(gp.getAllTimeBest());
    problem.showTree(gp.getAllTimeBest(), "mathproblem_best.png");
  }

  public static class FormulaFitnessFunction extends GPFitnessFunction {

    private final Object[] noArguments = new Object[0];

    @Override
    protected double evaluate(IGPProgram igpProgram) {
      double error = 0;
      for (int i = 0; i < input_size; i++) {
        vx.set(x[i]);
        try {
          double result = igpProgram.execute_float(0, this.noArguments);
          error += Math.abs(result - y[i]);

          if (Double.isInfinite(error)) {
            return Double.MAX_VALUE;
          }
        } catch (ArithmeticException ex) {
          System.out.println("x = " + x[i]);
          System.out.println(igpProgram);
          throw ex;
        }
      }

      if (error < 0.001) {
        error = 0.0d;
      }

      return error;
    }
  }

  @Override
  public GPGenotype create() throws InvalidConfigurationException {
    GPConfiguration conf = getGPConfiguration();
    Class[] types = {CommandGene.FloatClass};
    Class[][] argTypes = {{},};
    CommandGene[][] nodeSets = {{
            this.vx = Variable.create(conf, "X", CommandGene.FloatClass),
            new Pow(conf, CommandGene.FloatClass),
            new Multiply(conf, CommandGene.FloatClass),
            new Add(conf, CommandGene.FloatClass),
            new Divide(conf, CommandGene.FloatClass),
            new Subtract(conf, CommandGene.FloatClass),
            new Terminal(conf, CommandGene.FloatClass, 2.0d, 10.0d, true)}};

    return GPGenotype.randomInitialGenotype(conf, types, argTypes, nodeSets, 20, true);
  }
}
