import java.lang.reflect.Array;
import java.util.Arrays;

public class NeuralNetwork {
    public final double[][] hidden_layer_weights;
    public final double[][] output_layer_weights;
    private final int num_inputs;
    private final int num_hidden;
    private final int num_outputs;
    private final double learning_rate;
    public double[][] bias;

    public NeuralNetwork(int num_inputs, int num_hidden, int num_outputs, double[][] initial_hidden_layer_weights, double[][] initial_output_layer_weights, double learning_rate, double[][] initial_bias) {
        //Initialise the network
        this.num_inputs = num_inputs;
        this.num_hidden = num_hidden;
        this.num_outputs = num_outputs;
        System.out.println("outputs " + num_outputs);

        this.hidden_layer_weights = initial_hidden_layer_weights;
        this.output_layer_weights = initial_output_layer_weights;

        this.learning_rate = learning_rate;

        this.bias = initial_bias;
    }


    //Calculate neuron activation for an input
    public double sigmoid(double input) {
        double output = Double.NaN;

        output = (1/( 1 + Math.pow(Math.E,(-1*input))));

        return output;
    }

    //Feed forward pass input to a network output
    public double[][] forward_pass(double[] inputs) {
        double[] hidden_layer_outputs = new double[num_hidden];
        for (int i = 0; i < num_hidden; i++) {
            double weighted_sum = 0;
            for (int j = 0; j<inputs.length; j++){
                weighted_sum += hidden_layer_weights[j][i] * inputs[j] + bias[0][i];
            }
            double output = sigmoid(weighted_sum);
            hidden_layer_outputs[i] = output;
        }

        double[] output_layer_outputs = new double[num_outputs];

        for (int i = 0; i < num_outputs; i++) {
            double weighted_sum = 0;
            for (int j = 0; j<hidden_layer_outputs.length; j++){
                weighted_sum += output_layer_weights[j][i] * hidden_layer_outputs[j] + bias[1][i];
            }
            double output = sigmoid(weighted_sum);
            output_layer_outputs[i] = output;
        }

        return new double[][]{hidden_layer_outputs, output_layer_outputs};

    }

    public double[][][] backward_propagate_error(double[] inputs, double[] hidden_layer_outputs,
                                                 double[] output_layer_outputs, int desired_outputs) {

        double[] output_layer_betas = new double[num_outputs];
        int[] d_out = new int[3];
        if(desired_outputs == 0){
            d_out[0] = 1;

        }
        else if(desired_outputs == 1){
            d_out[1] = 1;
        }
        else {
            d_out[2] = 1;
        }
        for(int i = 0; i< num_outputs; i++){

            double beta = d_out[i] - output_layer_outputs[i];
            output_layer_betas[i] = beta;
        }

        //System.out.println("OL betas: " + Arrays.toString(output_layer_betas));

        double[] hidden_layer_betas = new double[num_hidden];
        for(int i = 0; i < num_outputs; i++){
            for(int j = 0; j < num_hidden; j++){
                double beta = output_layer_weights[j][i] * output_layer_outputs[j] * (1 - output_layer_outputs[j]) * output_layer_betas[j];
                hidden_layer_betas[j] += beta;
            }
        }
        //System.out.println("HL betas: " + Arrays.toString(hidden_layer_betas));

        // This is a HxO array (H hidden nodes, O outputs)
        double[][] delta_output_layer_weights = new double[num_hidden][num_outputs];
        for(int i = 0; i < num_outputs; i++){
            for( int j = 0; j < num_hidden; j++){
                double weightChange = learning_rate * hidden_layer_outputs[j] * output_layer_outputs[i] * (1 - output_layer_outputs[i]) * output_layer_betas[i];
                delta_output_layer_weights[j][i] = weightChange;
            }
        }

        // This is a IxH array (I inputs, H hidden nodes)
        double[][] delta_hidden_layer_weights = new double[num_inputs][num_hidden];
        for(int i = 0; i < num_hidden; i++){
            for(int j = 0; j < num_inputs; j ++){
                double weightChange = learning_rate * inputs[j] * hidden_layer_outputs[i] * (1 - hidden_layer_outputs[i]) * hidden_layer_betas[i];
                delta_hidden_layer_weights[j][i] = weightChange;
            }
        }

        double[][] bias_weight_change = new double[num_hidden][num_outputs];
       for(int i = 0; i < num_hidden; i++){
          double bias_change = learning_rate * hidden_layer_outputs[i] * (1 - hidden_layer_outputs[i]) * hidden_layer_betas[i];
          bias_weight_change[0][i] = bias_change;
       }
        for(int i = 0; i < num_outputs; i++){
            double bias_change = learning_rate * output_layer_outputs[i] * (1 - output_layer_outputs[i]) * output_layer_betas[i];
            bias_weight_change[1][i] = bias_change;
        }

        // Return the weights we calculated, so they can be used to update all the weights.
        return new double[][][]{delta_output_layer_weights, delta_hidden_layer_weights, bias_weight_change};
    }

    public void update_weights(double[][] delta_output_layer_weights, double[][] delta_hidden_layer_weights, double[][] bias_weight_change) {
        for(int i = 0; i < num_outputs; i++){
            for(int j = 0; j < num_hidden; j++){
                output_layer_weights[j][i] = output_layer_weights[j][i] + delta_output_layer_weights[j][i];
            }

        }
        for(int i = 0; i < num_hidden; i++){
            for(int j = 0; j < num_inputs; j++){
                hidden_layer_weights[j][i] = hidden_layer_weights[j][i] + delta_hidden_layer_weights[j][i];
            }
        }

        for(int i = 0; i < num_hidden; i++){
            bias[0][i] = bias[0][i] + bias_weight_change[0][i];
        }
        for(int i = 0; i < num_outputs; i++){
            bias[1][i] = bias[1][i] + bias_weight_change[1][i];
        }
    }

    public void train(double[][] instances, int[] desired_outputs, int epochs) {
        for (int epoch = 0; epoch < epochs; epoch++) {
            System.out.println("epoch = " + epoch);
            int[] predictions = new int[instances.length];
            double correct = 0;
            double incorrect = 0;
            for (int i = 0; i < instances.length; i++) {
                double[] instance = instances[i];
                double[][] outputs = forward_pass(instance);
                double[][][] delta_weights = backward_propagate_error(instance, outputs[0], outputs[1], desired_outputs[i]);
                int predicted_class = -1;

                double highestOutput = 0;
                for(int j = 0; j<=outputs[1].length-1; j++) {
                    if (outputs[1][j] > highestOutput) {
                        predicted_class = j;
                        highestOutput = outputs[1][j];
                    }
                }
                predictions[i] = predicted_class;

                //We use online learning, i.e. update the weights after every instance.
                update_weights(delta_weights[0], delta_weights[1], delta_weights[2]);
            }

            // Print new weights

            for(int i = 0; i < predictions.length; i++){
                if( desired_outputs[i] == predictions[i]){
                    correct++;
                }
                else incorrect++;
            }
            double acc = (correct / (correct + incorrect)) * 100;
            System.out.println("acc = " + acc);
            System.out.println("Hidden layer weights \n" + Arrays.deepToString(hidden_layer_weights));
            System.out.println("Output layer weights  \n" + Arrays.deepToString(output_layer_weights));
        }
    }

    public int[] predict(double[][] instances) {
        int[] predictions = new int[instances.length];
        for (int i = 0; i < instances.length; i++) {
            double[] instance = instances[i];
            double[][] outputs = forward_pass(instance);
            int predicted_class = -1;
            double highestOutput = 0;
            for(int j = 0; j<outputs[1].length; j++) {
                System.out.println("i: " + i + " " + "j: " + j + " " + outputs[1][j]);
                if (outputs[1][j] > highestOutput) {
                    predicted_class = j;
                    highestOutput = outputs[1][j];

                }
            }

            //System.out.println("Hidden layer weights \n" + Arrays.deepToString(hidden_layer_weights));
            //System.out.println("Output layer weights  \n" + Arrays.deepToString(output_layer_weights));

            predictions[i] = predicted_class;

        }
        return predictions;
    }

}
